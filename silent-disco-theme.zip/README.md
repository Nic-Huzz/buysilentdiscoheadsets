# Silent Disco Headsets - Shopify Theme

Your custom Shopify theme is ready to upload!

## 📦 What's Included

- ✅ Homepage with all sections (hero, brands, packages, timeline, etc.)
- ✅ Product pages with add-to-cart functionality
- ✅ Collection pages for browsing products
- ✅ Shopping cart
- ✅ Responsive mobile design
- ✅ ROI Calculator (Elfsight widget integrated)
- ✅ All your custom styling and branding

## 🚀 How to Upload to Shopify

### Option 1: Upload ZIP File (Easiest)

1. **Create a ZIP file:**
   - Select all files in the `shopify-theme` folder
   - Right-click → "Compress" (Mac) or "Send to → Compressed folder" (Windows)
   - Name it: `silent-disco-theme.zip`

2. **Upload to Shopify:**
   - Go to your Shopify admin: `yourstore.myshopify.com/admin`
   - Navigate to: **Online Store → Themes**
   - Scroll down to "Theme library"
   - Click **"Add theme" → "Upload ZIP file"**
   - Select your `silent-disco-theme.zip`
   - Wait for upload to complete

3. **Publish the theme:**
   - Once uploaded, click **"Publish"** on your new theme
   - Your site is live!

### Option 2: Use Shopify CLI (For Developers)

```bash
# Install Shopify CLI
npm install -g @shopify/cli @shopify/theme

# Navigate to theme folder
cd shopify-theme

# Login to Shopify
shopify login --store=yourstore.myshopify.com

# Push theme to Shopify
shopify theme push

# Or serve locally for development
shopify theme dev
```

## 🎨 After Upload - Setup Steps

### 1. Create Your First Product

1. Go to: **Products → Add product**
2. Add product details:
   - Title: "Starter Package" (or your product name)
   - Description: Product details
   - Price: $599 (or your price)
   - Images: Upload product photos

3. **For Package products:**
   - Add to collection: "Packages"
   - Add metafield for badge:
     - Namespace: `custom`
     - Key: `badge`
     - Value: "STARTER" (or "PRO", "CUSTOM")

### 2. Create Collections

1. Go to: **Products → Collections**
2. Create collection: "Packages"
3. Add your package products to this collection

### 3. Add Pages

Create these pages in: **Online Store → Pages**

- **About Us** (`/pages/about`)
- **Support** (`/pages/support`)
- **Legal** (`/pages/legal`)

### 4. Configure Navigation

1. Go to: **Online Store → Navigation**
2. Update main menu with your links
3. Update footer menu if needed

### 5. Connect Domain

1. Go to: **Settings → Domains**
2. Click **"Connect existing domain"**
3. Enter: `buysilentdiscoheadsets.com`
4. Follow Shopify's DNS setup instructions

## 📁 Theme Structure

```
shopify-theme/
├── assets/          # CSS, JS, and images
├── config/          # Theme settings
├── layout/          # Main theme layout (header/footer)
├── locales/         # Translations
├── templates/       # Page templates
│   ├── index.liquid       # Homepage
│   ├── product.liquid     # Product pages
│   ├── collection.liquid  # Collection pages
│   └── cart.liquid        # Shopping cart
└── README.md        # This file
```

## 🎯 Next Steps

1. **Upload theme** (see instructions above)
2. **Add products** in Shopify admin
3. **Create pages** (About, Support, Legal)
4. **Connect domain** (buysilentdiscoheadsets.com)
5. **Test checkout** with a test purchase
6. **Launch!** 🚀

## 💡 Tips

- **Test mode:** Use Shopify's test mode before going live
- **Payment setup:** Configure payment gateways in Settings → Payments
- **Shipping:** Set up shipping zones in Settings → Shipping
- **Taxes:** Configure tax settings in Settings → Taxes

## 🆘 Need Help?

- Shopify Help Center: https://help.shopify.com
- Shopify Community: https://community.shopify.com
- Theme Documentation: https://shopify.dev/docs/themes

## 🎨 Customization

To customize colors, fonts, or layout:
1. Edit `/assets/styles.css` for styling
2. Edit `/layout/theme.liquid` for header/footer
3. Edit `/templates/index.liquid` for homepage content

---

Built with Claude Code 🤖
Ready to sell Silent Disco Headsets! 🎧
