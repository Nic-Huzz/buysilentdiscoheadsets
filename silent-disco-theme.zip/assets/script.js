// Silent Disco Headsets - Interactive Elements

// ==================== //
// BRAND LOGO VIDEO ON HOVER/TAP
// ==================== //
document.addEventListener('DOMContentLoaded', function() {
  const brandLogos = document.querySelectorAll('.brand-logo');
  const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

  brandLogos.forEach(logo => {
    const video = logo.querySelector('.brand-video');

    if (video) {
      if (isTouchDevice) {
        // Mobile: Toggle on tap
        logo.addEventListener('click', (e) => {
          e.preventDefault();

          // Close other videos
          brandLogos.forEach(otherLogo => {
            if (otherLogo !== logo) {
              otherLogo.classList.remove('active');
              const otherVideo = otherLogo.querySelector('.brand-video');
              if (otherVideo) {
                otherVideo.pause();
                otherVideo.currentTime = 0;
              }
            }
          });

          // Toggle current video
          const isActive = logo.classList.contains('active');
          if (isActive) {
            logo.classList.remove('active');
            video.pause();
            video.currentTime = 0;
          } else {
            logo.classList.add('active');
            video.currentTime = 0;
            video.play().catch(err => console.log('Video play failed:', err));
          }
        });
      } else {
        // Desktop: Hover
        logo.addEventListener('mouseenter', () => {
          video.currentTime = 0;
          video.play().catch(err => console.log('Video play failed:', err));
        });

        logo.addEventListener('mouseleave', () => {
          video.pause();
          video.currentTime = 0;
        });
      }
    }
  });
});

// ==================== //
// FAQ ACCORDION
// ==================== //
document.addEventListener('DOMContentLoaded', function() {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');

    question.addEventListener('click', () => {
      // Close other open items
      faqItems.forEach(otherItem => {
        if (otherItem !== item && otherItem.classList.contains('active')) {
          otherItem.classList.remove('active');
        }
      });

      // Toggle current item
      item.classList.toggle('active');
    });
  });
});

// ==================== //
// TESTIMONIALS CAROUSEL
// ==================== //
const testimonials = [
  {
    text: "These headsets transformed our yoga retreat! The sound quality is incredible and our guests loved the silent disco experience. Highly recommend!",
    author: "Sarah Johnson",
    role: "Retreat Host, Bali",
    image: "https://i.pravatar.cc/400?img=1",
    video: null // Set to video path if available: "images/testimonial-video-1.mp4"
  },
  {
    text: "We've been using these headsets for our beach parties and they're absolutely perfect. The battery life is amazing and the LED colors create such a cool vibe!",
    author: "Mike Chen",
    role: "Event Organizer, Thailand",
    image: "https://i.pravatar.cc/400?img=3",
    video: null
  },
  {
    text: "As a corporate event planner, I need reliable equipment. These headsets exceeded all expectations. Professional quality at a great price point.",
    author: "Emma Williams",
    role: "Corporate Events Manager",
    image: "https://i.pravatar.cc/400?img=5",
    video: null
  },
  {
    text: "The customer service is outstanding! They helped us customize a package for our music festival. 500+ headsets working flawlessly. Thank you!",
    author: "David Rodriguez",
    role: "Festival Director",
    image: "https://i.pravatar.cc/400?img=7",
    video: null
  },
  {
    text: "Perfect for our meditation sessions. Crystal clear audio and the comfort level is unmatched. Our students can wear them for hours without any discomfort.",
    author: "Lisa Patel",
    role: "Wellness Center Owner",
    image: "https://i.pravatar.cc/400?img=9",
    video: null
  }
];

let currentTestimonial = 0;

function updateTestimonial(index) {
  const testimonial = testimonials[index];
  const card = document.querySelector('.testimonial-card');

  // Add fade out effect
  card.style.opacity = '0';

  setTimeout(() => {
    // Generate media HTML (image or video)
    const mediaHTML = testimonial.video
      ? `<video class="testimonial-video" autoplay loop muted playsinline>
           <source src="${testimonial.video}" type="video/mp4">
         </video>`
      : `<img src="${testimonial.image}" alt="${testimonial.author}" class="testimonial-image">`;

    card.innerHTML = `
      <div class="testimonial-media">
        ${mediaHTML}
      </div>
      <div class="testimonial-content">
        <p class="testimonial-text">"${testimonial.text}"</p>
        <div class="testimonial-author">${testimonial.author}</div>
        <div class="testimonial-role">${testimonial.role}</div>
      </div>
    `;

    // Fade in
    card.style.opacity = '1';
  }, 300);

  // Update active dot
  document.querySelectorAll('.carousel-dot').forEach((dot, i) => {
    dot.classList.toggle('active', i === index);
  });

  currentTestimonial = index;
}

// Carousel dot navigation
document.addEventListener('DOMContentLoaded', function() {
  const dots = document.querySelectorAll('.carousel-dot');

  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      const index = parseInt(dot.getAttribute('data-index'));
      updateTestimonial(index);
    });
  });

  // Auto-rotate testimonials every 5 seconds
  setInterval(() => {
    const nextIndex = (currentTestimonial + 1) % testimonials.length;
    updateTestimonial(nextIndex);
  }, 5000);
});

// ==================== //
// SMOOTH SCROLLING
// ==================== //
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const href = this.getAttribute('href');

    // Only prevent default for anchor links, not empty hrefs
    if (href !== '#' && href.length > 1) {
      e.preventDefault();

      const target = document.querySelector(href);
      if (target) {
        const headerOffset = 80;
        const elementPosition = target.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    }
  });
});

// ==================== //
// HEADER SCROLL EFFECT
// ==================== //
let lastScroll = 0;
const header = document.querySelector('.header');

window.addEventListener('scroll', () => {
  const currentScroll = window.pageYOffset;

  // Add shadow when scrolled
  if (currentScroll > 0) {
    header.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.12)';
  } else {
    header.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.08)';
  }

  lastScroll = currentScroll;
});

// ==================== //
// MOBILE MENU TOGGLE
// ==================== //
document.addEventListener('DOMContentLoaded', function() {
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');

  if (menuToggle && nav) {
    menuToggle.addEventListener('click', () => {
      nav.classList.toggle('active');
      menuToggle.classList.toggle('active');
    });
  }
});

// ==================== //
// NEWSLETTER FORM
// ==================== //
document.addEventListener('DOMContentLoaded', function() {
  const newsletterForm = document.querySelector('.newsletter-form');

  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const emailInput = newsletterForm.querySelector('.newsletter-input');
      const email = emailInput.value;

      // Simple validation
      if (email && email.includes('@')) {
        alert('Thank you for subscribing! We\'ll keep you updated with our latest offers and news.');
        emailInput.value = '';
      } else {
        alert('Please enter a valid email address.');
      }
    });
  }
});

// ==================== //
// ADD TO CART BUTTONS
// ==================== //
document.addEventListener('DOMContentLoaded', function() {
  const packageButtons = document.querySelectorAll('.package-card button');

  packageButtons.forEach(button => {
    button.addEventListener('click', () => {
      const packageCard = button.closest('.package-card');
      const packageName = packageCard.querySelector('h3').textContent;

      // Simulate add to cart action
      button.innerHTML = '✓ Added to Cart';
      button.style.background = 'linear-gradient(135deg, #5e17eb, #8b5cf6)';
      button.style.color = 'white';
      button.style.border = 'none';

      setTimeout(() => {
        const originalText = button.textContent.includes('Quote') ? 'Get Quote' :
                            button.textContent.includes('Contact') ? 'Contact Us' :
                            'Select Package';
        button.innerHTML = originalText;
        button.style.background = '';
        button.style.color = '';
        button.style.border = '';
      }, 2000);

      // You can replace this with actual cart functionality
      console.log(`Added ${packageName} to cart`);
    });
  });
});

// ==================== //
// INTERSECTION OBSERVER FOR ANIMATIONS
// ==================== //
document.addEventListener('DOMContentLoaded', function() {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);

  // Animate sections on scroll
  const sections = document.querySelectorAll('.section, .section-sm');
  sections.forEach(section => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(30px)';
    section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(section);
  });
});
